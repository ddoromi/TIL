# 181219 수업정리

## 1. LIST, DICT 문제풀이

- chocolatey
  - 윈도우 패키지 매니저
- python -V 3.6.7
- git 
  - Version Control System
- vscode
  - Code Editor
- chrome
  - Browser

## 2. list