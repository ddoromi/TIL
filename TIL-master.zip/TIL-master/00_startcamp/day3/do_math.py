# import math_functions
#
# math_functions.cube(5)
# math_functions.average([10,20,30])

from math_functions import cube, average

print(cube(5))
print(average([10,20,30]))