from lotto_functions import am_i_lucky, pick_lotto, get_lotto

result = am_i_lucky(pick_lotto(), get_lotto(837))
print(result)