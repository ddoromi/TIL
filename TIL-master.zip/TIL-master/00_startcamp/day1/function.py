print('hi')
len('hi') # 2
len([1,2,3,4,5]) # 5
type('a')

scores = [45, 60, 78, 88]
high_score = max(scores)
lowest_score = min(scores)
round(1.8)
round(1.876, 2)

first = [11.25, 18.0, 20.0]
second = [10.75, 9.50]

# full 에 first 와 second 을 합쳐서 저장

# full_sorted 에 full 을 오름차순으로 정렬해서 저장
full_sorted = sorted(full)

# *reverse_sorted 에 full 을 내림차순으로 정렬해서 저장
reverse_sorted = sorted(full, reverse=True)