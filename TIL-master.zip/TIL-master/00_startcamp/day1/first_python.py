print(10 ** 2)

first_name = 'taeyoung'
last_name = 'yu'
full_name = last_name + first_name
print(full_name)

height = 1.75
weight = 74
bmi = weight / height ** 2

x = True 
y = 1
z = 10.4

print(type(x)) 
print(type(y)) 
print(type(z)) 