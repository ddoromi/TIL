my_list = [4, 7, 9, 1, 3, 6]
# 최대/최소
max(my_list)
min(my_list)
# 특정 요소의 인덱스?
my_list.index()
# 리스트를 뒤집으려면?
my_list.reverse()

dust = 100 # <class: int>
lang = 'python' # str
samsung = ['elec', 'sds', 's1'] # list

lang.capitalize()
lang.replace('on', 'off')

samsung.index('sds')
saumsung.append('bio') # 원본이 바뀐다!