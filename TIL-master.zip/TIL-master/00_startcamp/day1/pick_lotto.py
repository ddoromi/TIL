import random

numbers = list(range(1, 46))

my_numbers = random.sample(numbers, 6)
my_numbers.sort()

print(my_numbers)
